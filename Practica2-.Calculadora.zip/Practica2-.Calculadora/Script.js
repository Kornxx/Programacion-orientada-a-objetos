function catalogo() {
    let seleccion = document.getElementById("menuSelector").value;
    document.querySelectorAll('.seccion').forEach(div => div.style.display = 'none');
    if (seleccion) {
        document.getElementById(seleccion).style.display = 'block';
    }
}

function Areatriangulo() {
    let baseT = prompt("Ingrese la base del Triangulo");
    let alturaT = prompt("Ingrese la altura del triangulo");
    if (baseT && alturaT) {
        let area = (baseT * alturaT) / 2;
        let resultado = "Área Triángulo: " + area;
        alert(resultado);
        localStorage.setItem("ultimoCalculo", resultado); 
    }
}

function VolumenEsfera() {
    let radioE = document.getElementById("radioEsfera").value;
    if (radioE) {
        let volumenE = (4 / 3) * Math.PI * Math.pow(radioE, 3);
        let textoResultado = "Tu volumen es: " + volumenE.toFixed(2);
        document.getElementById("resultadoVolumen").innerHTML = textoResultado;
        localStorage.setItem("ultimoCalculo", textoResultado); 
    }
}

function Conversionmoneda() {
    let cantidadP = document.getElementById("cantidadPesos").value;
    let dolares = document.getElementById("dolares").value;
    if (cantidadP && dolares) {
        let conversionD = cantidadP / dolares;
        let textoResultado = "Son " + conversionD.toFixed(2) + " dolares";
        document.getElementById("resultadoConversion").innerHTML = textoResultado;
        localStorage.setItem("ultimoCalculo", textoResultado); 
    }
}

function limpiador() {
    document.getElementById("radioEsfera").value = "";
    document.getElementById("cantidadPesos").value = "";
    document.getElementById("dolares").value = "";
    document.getElementById("resultadoVolumen").innerHTML = "";
    document.getElementById("resultadoConversion").innerHTML = "";

}

window.onload = function() {
    let historial = localStorage.getItem("ultimoCalculo");
    if (historial) {
        console.log("Historial detectado: " + historial);
        let mensaje = document.createElement("p");
        mensaje.innerHTML = "<strong>Recordatorio:</strong> " + historial;
        mensaje.style.color = "#555";
        mensaje.style.textAlign = "center";
        document.body.insertBefore(mensaje, document.body.firstChild);
    }
};