function sumahastaN() {
    let Nlimit=parseInt(document.getElementById("Nlimit").value);
    let suma=0;
    for (let i=1;i<=Nlimit;i++) {
        suma+=i;
    }
    document.getElementById("primerE").innerHTML= "La sumatoria es: "+ suma;
}
function calcularFactorial() {
    let n=parseInt(document.getElementById("numFactorial").value);
    let factorial=1;
    for (let i=1;i<=n;i++) {
        factorial*=i;
    }
    document.getElementById("resultadoFactorial").innerHTML = "El factorial de " + n + " es: " + factorial;
}
function ejecutarR() {
    let entrada = document.getElementById("numReto").value;
    let divResultado = document.getElementById("resultadoReto");
    let n = Number(entrada);
    
    if (isNaN(n)||!Number.isInteger(n)||n<=0) {
        divResultado.innerHTML= "<span style='color: red;'>Error: Ingresa un número entero positivo mayor a 0.</span>";
        return;
    }
    let serie="";
    let sumaTotal=0;
    for (let i=1;i<=n;i++) {
        serie+=i + (i < n ? ", " : "");
        sumaTotal += i;
    }
    let tipoSuma= (n % 2 === 0) ? "Par" : "Impar";
    divResultado.innerHTML= `
        <p><strong>Serie:</strong> ${serie}</p>
        <p><strong>Suma Total:</strong> ${sumaTotal}</p>
        <p><strong>El número ${n} es:</strong> ${tipoSuma}</p>
    `;
}