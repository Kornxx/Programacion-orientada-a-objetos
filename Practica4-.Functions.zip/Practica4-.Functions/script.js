function esPar(numero) {
    return (numero % 2 === 0) ? "El número " + numero + " es Par" : "El número " + numero + " es Impar";
}

const calcularFactorial = function(n) {
    if (n < 0) return "No definido";
    let resultado = 1;
    for (let i = 2; i <= n; i++) {
        resultado *= i;
    }
    return resultado;
};

const sumarElementos = (arreglo) => arreglo.reduce((acc, valor) => acc + valor, 0);

function ejecutarSumaArray() {
    let texto = document.getElementById("inputArray").value;
    let numeros = texto.split(',').map(Number);
    document.getElementById("resArray").innerHTML = "La suma total es: " + sumarElementos(numeros);
}
function cuadradoTradicional(n) { return n * n; }
const cuadradoAnonimo = function(n) { return n * n; };
const cuadradoArrow = n => n * n;

const mensajeFinal = (valor) => "Resultado final: " + valor;

const procesarDato = function(num) {
    let doble = num * 2;
    return mensajeFinal(doble);
};

function iniciarPrograma(entrada) {
    return procesarDato(entrada);
}

function ejecutarParidad() {
    let n = parseInt(document.getElementById("numParidad").value);
    document.getElementById("resParidad").innerHTML = esPar(n);
}

function ejecutarFactorial() {
    let n = parseInt(document.getElementById("numFact").value);
    document.getElementById("resFact").innerHTML = "Resultado: " + calcularFactorial(n);
}



function compararCuadrados() {
    let n = parseInt(document.getElementById("numCuadrado").value);
    let r1 = cuadradoTradicional(n);
    let r2 = cuadradoAnonimo(n);
    let r3 = cuadradoArrow(n);
    document.getElementById("resCuadrados").innerHTML = 
        "Tradicional: " + r1 + "<br>Anónima: " + r2 + "<br>Arrow: " + r3;
}

function iniciarCascada() {
    let n = parseInt(document.getElementById("numCascada").value);
    document.getElementById("resCascada").innerHTML = iniciarPrograma(n);
}