function mostrarmensajeexterno(){
    alert("Hola desde el java script externo!")
}